import { initI18n, setLang, getLang, t, applyStaticI18n } from '../i18n.js';
import { delimForFile, detectDelimiter, parseVocabFull, buildDiff, applyMerge, vocabRowsToText } from '../vocab-import.js';

// ── i18n boot ─────────────────────────────────────────────────────────────────
await initI18n();
applyStaticI18n();
document.getElementById('lang-select').value = getLang();
document.getElementById('lang-select').addEventListener('change', async e => {
  await setLang(e.target.value);
  applyStaticI18n();
  renderProfiles();
  renderAnalytics(globalProfiles[globalActiveId]?.analyticsHistory || []);
  renderVocab(globalRows, globalColNames);
  renderBlacklist(globalProfiles[globalActiveId]?.disabledHosts || []);
});

// ── Tab switching ─────────────────────────────────────────────────────────────
document.querySelectorAll('.tab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(s => s.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
  });
});

const hashParts = (location.hash || '').replace('#', '').split('&');
if (hashParts.includes('profiles')) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(s => s.classList.remove('active'));
  document.querySelector('[data-tab="profiles"]').classList.add('active');
  document.getElementById('tab-profiles').classList.add('active');
}
if (hashParts.includes('new=1')) {
  document.getElementById('new-profile-name').value = '';
  document.getElementById('new-profile-email').value = '';
  document.getElementById('new-profile-file').value = '';
  document.getElementById('modal-new-profile').style.display = 'flex';
}

fetch(chrome.runtime.getURL('manifest.json'))
  .then(r => r.json())
  .then(m => { document.getElementById('version-label').textContent = 'v' + m.version; });

// ── UUID helper ───────────────────────────────────────────────────────────────
function generateUUID() {
  return [...crypto.getRandomValues(new Uint8Array(8))]
    .map(b => b.toString(16).padStart(2, "0"))
    .join("");
}

// ── State ─────────────────────────────────────────────────────────────────────
let globalRows = [];
let globalColNames = ['target', 'translations'];
let globalVocabName = 'lingoblend-vocab';
let globalProfiles = {};
let globalActiveId = '';

chrome.storage.local.get(['vocabText', 'vocabName', 'vocabColNames', 'disabledHosts',
                          'analyticsHistory', 'profiles', 'activeProfileId'])
  .then(data => {
    globalProfiles = data.profiles || {};
    globalActiveId = data.activeProfileId || '';

    const activeProfile = globalProfiles[globalActiveId];
    if (activeProfile) {
      document.getElementById('header-profile-name').textContent = activeProfile.name;
    }

    renderProfiles();
    renderAnalytics(data.analyticsHistory || []);

    globalVocabName = data.vocabName || 'lingoblend-vocab';
    globalColNames = data.vocabColNames || ['target', 'translations'];
    if (data.vocabText) {
      const delim = data.vocabText.includes('\t') ? '\t' : ';';
      const parsed = parseVocabFull(data.vocabText, delim);
      globalRows = parsed.rows;
      if (parsed.colNames && parsed.colNames.length) globalColNames = parsed.colNames;
    }
    renderVocab(globalRows, globalColNames);
    renderBlacklist(data.disabledHosts || []);
  });

// ══ PROFILES TAB ══════════════════════════════════════════════════════════════
async function syncFlatFromProfile(profile) {
  await chrome.storage.local.set({
    vocabText:        profile.vocabText        || '',
    vocabName:        profile.vocabName        || '',
    vocabCount:       profile.vocabCount       || 0,
    vocabDelimiter:   profile.vocabDelimiter   || '\t',
    disabledHosts:    profile.disabledHosts    || [],
    analyticsHistory: profile.analyticsHistory || [],
    nativeLanguage:   profile.nativeLanguage   || 'pl'
  });
}

const LANG_LABELS = { pl: 'PL', en: 'EN', es: 'ES' };

function renderProfiles() {
  const container = document.getElementById('profile-cards');
  container.innerHTML = '';
  const count = Object.keys(globalProfiles).length;

  for (const id of Object.keys(globalProfiles)) {
    const p = globalProfiles[id];
    const isActive = id === globalActiveId;
    const card = document.createElement('div');
    card.className = 'profile-card' + (isActive ? ' active' : '');

    const nL = LANG_LABELS[p.nativeLanguage] || p.nativeLanguage.toUpperCase();
    const tL = LANG_LABELS[p.targetLanguage] || p.targetLanguage.toUpperCase();
    const wordCount = p.vocabCount || 0;
    const lastUsed = p.lastUsedAt
      ? new Date(p.lastUsedAt).toLocaleDateString(undefined, { day: '2-digit', month: 'short', year: 'numeric' })
      : '—';

    card.innerHTML = `
      <div class="profile-card-info">
        <div class="profile-card-name-row">
          <span class="profile-card-name" id="pname-${id}">${p.name}</span>
          <input class="profile-card-name-input" id="pname-input-${id}" value="${p.name}" hidden>
          <span class="btn-edit-name" data-id="${id}" title="${t('tooltip_edit_name')}">✎</span>
        </div>
        <div class="profile-card-meta">
          <span class="profile-card-lang">${nL} → ${tL}</span>
          <span>${t('words_count', { count: wordCount })}</span>
          <span>${t('last_used', { date: lastUsed })}</span>
        </div>
      </div>
      <div class="profile-card-actions">
        <button class="btn-profile-action btn-set-active" data-id="${id}" ${isActive ? 'disabled' : ''}>${t('btn_set_active')}</button>
        <button class="btn-profile-action btn-delete-profile" data-id="${id}" ${count <= 1 ? 'disabled' : ''}>${t('btn_delete')}</button>
        <button class="btn-profile-action btn-export-profile" data-id="${id}">${t('btn_export_profile')}</button>
      </div>`;
    container.appendChild(card);
  }

  container.querySelectorAll('.btn-set-active').forEach(btn => {
    btn.addEventListener('click', () => setActiveProfile(btn.dataset.id));
  });
  container.querySelectorAll('.btn-delete-profile').forEach(btn => {
    btn.addEventListener('click', () => deleteProfile(btn.dataset.id));
  });
  container.querySelectorAll('.btn-export-profile').forEach(btn => {
    btn.addEventListener('click', () => exportProfile(btn.dataset.id));
  });

  container.querySelectorAll('.btn-edit-name').forEach(btn => {
    const id = btn.dataset.id;
    const span  = document.getElementById(`pname-${id}`);
    const input = document.getElementById(`pname-input-${id}`);
    let committing = false;

    btn.addEventListener('click', () => {
      span.hidden = true;
      input.hidden = false;
      input.focus();
      input.select();
    });

    async function commitRename() {
      if (committing) return;
      committing = true;
      const newName = input.value.trim();
      if (!newName) { cancelRename(); committing = false; return; }
      globalProfiles[id].name = newName;
      await chrome.storage.local.set({ profiles: globalProfiles });
      span.textContent = newName;
      span.hidden = false;
      input.hidden = true;
      if (id === globalActiveId) {
        document.getElementById('header-profile-name').textContent = newName;
      }
      committing = false;
    }

    function cancelRename() {
      input.value = span.textContent;
      span.hidden = false;
      input.hidden = true;
    }

    input.addEventListener('blur', commitRename);
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter')  { e.preventDefault(); commitRename(); }
      if (e.key === 'Escape') { e.preventDefault(); cancelRename(); }
    });
  });
}

async function setActiveProfile(id) {
  const profile = globalProfiles[id];
  if (!profile) return;
  profile.lastUsedAt = Date.now();
  globalProfiles[id] = profile;
  globalActiveId = id;

  await chrome.storage.local.set({ activeProfileId: id, profiles: globalProfiles });
  await syncFlatFromProfile(profile);

  document.getElementById('header-profile-name').textContent = profile.name;
  renderProfiles();

  const delim = (profile.vocabText || '').includes('\t') ? '\t' : ';';
  const parsed = profile.vocabText
    ? parseVocabFull(profile.vocabText, delim)
    : { rows: [], colNames: ['target', 'translations'] };
  globalRows = parsed.rows;
  globalColNames = parsed.colNames?.length ? parsed.colNames : ['target', 'translations'];
  globalVocabName = profile.vocabName || 'lingoblend-vocab';
  renderVocab(globalRows, globalColNames);
  renderAnalytics(profile.analyticsHistory || []);
  renderBlacklist(profile.disabledHosts || []);
}

async function deleteProfile(id) {
  if (Object.keys(globalProfiles).length <= 1) return;
  delete globalProfiles[id];
  if (id === globalActiveId) {
    const firstId = Object.keys(globalProfiles)[0];
    globalActiveId = firstId;
    await chrome.storage.local.set({ activeProfileId: firstId, profiles: globalProfiles });
    await syncFlatFromProfile(globalProfiles[firstId]);
    document.getElementById('header-profile-name').textContent = globalProfiles[firstId].name;
  } else {
    await chrome.storage.local.set({ profiles: globalProfiles });
  }
  renderProfiles();
}

function exportProfile(id) {
  const profile = globalProfiles[id];
  if (!profile) return;
  const blob = new Blob([JSON.stringify(profile, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `lingoblend-profile-${profile.id.replace(/\s+/g, '_')}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

// ── New profile modal ────────────────────────────────────────────────────────
document.getElementById('btn-new-profile').addEventListener('click', () => {
  document.getElementById('new-profile-name').value = '';
  document.getElementById('new-profile-file').value = '';
  document.getElementById('modal-new-profile').style.display = 'flex';
});

document.getElementById('btn-create-profile-confirm').addEventListener('click', async () => {
  const name = document.getElementById('new-profile-name').value.trim();
  const nativeLang = document.getElementById('new-profile-native').value;
  const targetLang = document.getElementById('new-profile-target').value;
  const fileInput = document.getElementById('new-profile-file');
  const file = fileInput.files[0];

  if (!name || !file) {
    alert(t('require_fields_alert'));
    return;
  }

  const text = await file.text();
  const lines = text.split(/\r?\n/);
  const firstLine = lines.find(l => l.trim());
  let delim = delimForFile(file.name);
  if (!delim && firstLine) delim = detectDelimiter(firstLine);
  if (!delim) { alert(t('delimiter_error')); return; }

  const { rows, colNames } = parseVocabFull(text, delim);
  if (!rows.length) { alert(t('no_valid_rows')); return; }

  const vocabText = vocabRowsToText(rows, colNames, delim);
  const id = generateUUID();
  const now = Date.now();

  globalProfiles[id] = {
    id, name,
    nativeLanguage: nativeLang, targetLanguage: targetLang,
    vocabText, vocabName: file.name.replace(/\.[^.]+$/, ''), vocabCount: rows.length,
    vocabDelimiter: delim, vocabColNames: colNames,
    analyticsHistory: [], disabledHosts: [],
    createdAt: now, lastUsedAt: now
  };
  globalActiveId = id;

  await chrome.storage.local.set({ profiles: globalProfiles, activeProfileId: id });
  await syncFlatFromProfile(globalProfiles[id]);
  document.getElementById('header-profile-name').textContent = name;

  const parsed = parseVocabFull(vocabText, delim);
  globalRows = parsed.rows;
  globalColNames = colNames;
  globalVocabName = globalProfiles[id].vocabName;
  renderVocab(globalRows, globalColNames);
  renderAnalytics([]);
  renderBlacklist([]);

  document.getElementById('modal-new-profile').style.display = 'none';
  renderProfiles();
});

document.getElementById('btn-create-profile-cancel').addEventListener('click', () => {
  document.getElementById('modal-new-profile').style.display = 'none';
});

// ── Import profile ────────────────────────────────────────────────────────────
document.getElementById('btn-import-profile').addEventListener('click', () => {
  document.getElementById('profile-file-input').click();
});

document.getElementById('profile-file-input').addEventListener('change', async e => {
  const file = e.target.files[0];
  if (!file) return;
  e.target.value = '';
  try {
    const profile = JSON.parse(await file.text());
    if (!profile.id || !profile.name) throw new Error();
    globalProfiles[profile.id] = profile;
    await chrome.storage.local.set({ profiles: globalProfiles });
    renderProfiles();
  } catch (_) {
    alert(t('invalid_profile_file'));
  }
});

// ══ ANALYTICS TAB ════════════════════════════════════════════════════════════
function renderAnalytics(history) {
  const totalSessions = history.length;
  const sites = new Set(history.map(h => h.hostname)).size;
  const avgPct = history.length
    ? Math.round(history.reduce((s, h) => s + h.avgPct, 0) / history.length) : 0;
  const totalHighCov = history.reduce((s, h) => s + (h.highCoverageCount || 0), 0); //unused - total count of high-coverage sentences across all sessions
  const missingFreq = {};
  for (const entry of history)
    for (const w of (entry.topMissing || []))
      missingFreq[w] = (missingFreq[w] || 0) + 1;
  const sortedMissing = Object.entries(missingFreq).sort((a, b) => b[1] - a[1]).slice(0, 60);
  const maxFreq = sortedMissing[0]?.[1] || 1;

  document.getElementById('summary-cards').innerHTML = `
    <div class="summary-card">
      <span class="card-label">${t('sessions_label')}</span>
      <span class="card-val">${totalSessions}</span>
      <span class="card-sub">${t('sessions_sub')}</span>
    </div>
    <div class="summary-card">
      <span class="card-label">${t('sites_label')}</span>
      <span class="card-val">${sites}</span>
      <span class="card-sub">${t('sites_sub')}</span>
    </div>
    <div class="summary-card">
      <span class="card-label">${t('avg_coverage_card')}</span>
      <span class="card-val">${avgPct}%</span>
      <span class="card-sub">${t('avg_coverage_sub')}</span>
    </div>
    <div class="summary-card">
      <span class="card-label">${t('missing_links_card')}</span>
      <span class="card-val">${sortedMissing.length}</span>
      <span class="card-sub">${t('missing_links_sub')}</span>
    </div>`;

  const cloud = document.getElementById('missing-cloud');
  if (!sortedMissing.length) {
    cloud.innerHTML = `<span style="color:#bab9b4;font-size:13px">${t('no_data_yet')}</span>`;
  } else {
    cloud.innerHTML = sortedMissing.map(([w, f]) => {
      const cls = f >= maxFreq * 0.6 ? 'word-chip freq-high' : f >= maxFreq * 0.3 ? 'word-chip freq-med' : 'word-chip';
      return `<span class="${cls}">${w}</span>`;
    }).join('');
  }

  const list = document.getElementById('history-list');
  if (!history.length) {
    list.innerHTML = `<p class="empty-msg">${t('no_history')}</p>`;
    return;
  }
  list.innerHTML = history.map(h => {
    const dt = new Date(h.ts);
    const dateStr = dt.toLocaleDateString(undefined, { day: '2-digit', month: 'short', year: 'numeric' });
    const timeStr = dt.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
    const preview = (h.topMissing || []).slice(0, 6).join(', ');
    return `<div class="history-row">
      <span class="history-hostname">${h.hostname}</span>
      <span class="history-ts">${dateStr} ${timeStr}</span>
      <span class="history-pct">${t('history_pct_coverage', { pct: h.avgPct })}</span>
      <span class="history-missing">${t('history_high_cov', { count: h.highCoverageCount })}</span>
      ${preview ? `<span class="history-words">${t('history_missing_links', { list: preview })}</span>` : ''}
    </div>`;
  }).join('');
}

// ══ VOCABULARY TAB ════════════════════════════════════════════════════════════
function renderVocab(rows, colNames) {
  const badge = document.getElementById('vocab-count-badge');
  badge.textContent = t('words_count', { count: rows.length });

  const thead = document.getElementById('vocab-thead');
  const tbody = document.getElementById('vocab-tbody');

  thead.innerHTML = `<tr>${colNames.map(c => `<th>${c}</th>`).join('')}<th class="td-actions"></th></tr>`;

  const search = document.getElementById('vocab-search').value.toLowerCase();
  const filtered = search ? rows.filter(r =>
    colNames.some(c => (r[c] || '').toLowerCase().includes(search))
  ) : rows;

  tbody.innerHTML = '';
  filtered.forEach((row, idx) => {
    const realIdx = rows.indexOf(row);
    const tr = document.createElement('tr');
    tr.innerHTML = colNames.map((c, ci) =>
      `<td class="${ci === 0 ? 'td-target' : 'td-trans'}">${row[c] || ''}</td>`
    ).join('') +
    `<td class="td-actions">
      <button class="btn-edit-row" data-idx="${realIdx}">✎</button>
      <button class="btn-del-row" data-idx="${realIdx}">✕</button>
    </td>`;
    tbody.appendChild(tr);
  });

  tbody.querySelectorAll('.btn-edit-row').forEach(btn => {
    btn.addEventListener('click', () => editVocabRow(parseInt(btn.dataset.idx)));
  });
  tbody.querySelectorAll('.btn-del-row').forEach(btn => {
    btn.addEventListener('click', () => deleteVocabRow(parseInt(btn.dataset.idx)));
  });
}

document.getElementById('vocab-search').addEventListener('input', () => renderVocab(globalRows, globalColNames));

function editVocabRow(idx) {
  const row = globalRows[idx];
  if (!row) return;
  const tbody = document.getElementById('vocab-tbody');
  const tr = tbody.querySelector(`[data-idx="${idx}"]`)?.closest('tr');
  if (!tr) return;

  tr.innerHTML = globalColNames.map(c =>
    `<td><input class="edit-input" data-col="${c}" value="${(row[c] || '').replace(/"/g, '&quot;')}" style="width:100%"></td>`
  ).join('') +
  `<td class="td-actions">
    <button class="btn-save-row" data-idx="${idx}">${t('btn_save')}</button>
    <button class="btn-cancel-row" data-idx="${idx}">✕</button>
  </td>`;

  tr.querySelector('.btn-save-row').addEventListener('click', async () => {
    globalColNames.forEach(c => {
      row[c] = tr.querySelector(`[data-col="${c}"]`).value.trim();
    });
    globalRows[idx] = row;
    await saveVocabRows();
    renderVocab(globalRows, globalColNames);
  });
  tr.querySelector('.btn-cancel-row').addEventListener('click', () => renderVocab(globalRows, globalColNames));
}

async function deleteVocabRow(idx) {
  globalRows.splice(idx, 1);
  await saveVocabRows();
  renderVocab(globalRows, globalColNames);
}

async function saveVocabRows() {
  const text = vocabRowsToText(globalRows, globalColNames, ';');
  const data = await chrome.storage.local.get(['profiles', 'activeProfileId']);
  const profiles = data.profiles || {};
  const activeId = data.activeProfileId;
  if (activeId && profiles[activeId]) {
    profiles[activeId].vocabText = text;
    profiles[activeId].vocabCount = globalRows.length;
  }
  await chrome.storage.local.set({ vocabText: text, vocabCount: globalRows.length, profiles });
}

// ── Vocab export ──────────────────────────────────────────────────────────────
document.getElementById('btn-export-dash').addEventListener('click', () => {
  const text = vocabRowsToText(globalRows, globalColNames, ';');
  const now = new Date();
  const stamp = now.toISOString().slice(0, 10) + '_' +
    String(now.getHours()).padStart(2, '0') +
    String(now.getMinutes()).padStart(2, '0');
  const blob = new Blob([text], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${globalVocabName}_${stamp}.csv`;
  a.click();
  URL.revokeObjectURL(url);
});

// ── Vocab import (shared diff modal state) ──────────────────────────────────
const modalDiff = document.getElementById('modal-diff');
const modalDiffBody = document.getElementById('modal-diff-body');
let diffResolve = null;

function showDiffModal(diff) {
  modalDiffBody.innerHTML = `
    <strong style="color:#437a22">${t('diff_added', { count: diff.newWords.length })}</strong>&nbsp;
    <strong style="color:#da7101">${t('diff_modified', { count: diff.updated.length })}</strong>&nbsp;
    <strong style="color:#7a7974">${t('diff_unchanged', { count: diff.unchanged.length })}</strong>&nbsp;
    <strong style="color:#a12c7b">${t('diff_removed', { count: diff.removed.length })}</strong>
  `;
  modalDiff.style.display = 'flex';
  return new Promise(res => { diffResolve = res; });
}

document.getElementById('diff-add-new').addEventListener('click', () => { modalDiff.style.display = 'none'; diffResolve?.('addnew'); diffResolve = null; });
document.getElementById('diff-add-update').addEventListener('click', () => { modalDiff.style.display = 'none'; diffResolve?.('addupdate'); diffResolve = null; });
document.getElementById('diff-replace').addEventListener('click', () => { modalDiff.style.display = 'none'; diffResolve?.('replace'); diffResolve = null; });
document.getElementById('diff-cancel').addEventListener('click', () => { modalDiff.style.display = 'none'; diffResolve?.(null); diffResolve = null; });

async function handleImport(text, fileName) {
  const lines = text.split(/\r?\n/);
  const firstLine = lines.find(l => l.trim());
  let delim = delimForFile(fileName);
  if (!delim && firstLine) delim = detectDelimiter(firstLine);
  if (!delim) { alert(t('delimiter_error')); return; }

  const { rows: incoming, colNames } = parseVocabFull(text, delim);
  if (!incoming.length) { alert(t('no_valid_rows')); return; }

  const existingText = globalProfiles[globalActiveId]?.vocabText || '';
  const existingDelim = existingText.includes('\t') ? '\t' : ';';
  const { rows: existing } = existingText ? parseVocabFull(existingText, existingDelim) : { rows: [] };

  const diff = buildDiff(incoming, existing);
  const mode = await showDiffModal(diff);
  if (!mode) return;

  const merged = applyMerge(mode, incoming, existing);
  const newText = vocabRowsToText(merged, colNames, delim);
  const name = fileName.replace(/\.[^.]+$/, '');
  const count = merged.length;

  if (globalActiveId && globalProfiles[globalActiveId]) {
    globalProfiles[globalActiveId].vocabText = newText;
    globalProfiles[globalActiveId].vocabName = name;
    globalProfiles[globalActiveId].vocabCount = count;
    globalProfiles[globalActiveId].vocabDelimiter = delim;
    globalProfiles[globalActiveId].vocabColNames = colNames;
  }

  globalRows = merged;
  globalColNames = colNames;
  globalVocabName = name;

  await chrome.storage.local.set({
    vocabText: newText, vocabName: name, vocabCount: count,
    vocabColNames: colNames, vocabDelimiter: delim,
    profiles: globalProfiles
  });
  renderVocab(globalRows, globalColNames);
}

document.getElementById('btn-import-dash').addEventListener('click', () => document.getElementById('dash-file-input').click());
document.getElementById('dash-file-input').addEventListener('change', async e => {
  const file = e.target.files[0];
  if (!file) return;
  e.target.value = '';
  await handleImport(await file.text(), file.name);
});

// ══ MUTED SITES TAB ═══════════════════════════════════════════════════════════
function renderBlacklist(hosts) {
  const ul = document.getElementById('blacklist-ul');
  if (!hosts.length) {
    ul.innerHTML = `<p class="empty-msg">${t('no_muted_sites')}</p>`;
    return;
  }
  ul.innerHTML = hosts.map(h =>
    `<li class="blacklist-item">
      <span class="blacklist-hostname">${h}</span>
      <button class="btn-whitelist" data-host="${h}">${t('btn_reenable')}</button>
    </li>`
  ).join('');
  ul.querySelectorAll('.btn-whitelist').forEach(btn => {
    btn.addEventListener('click', async () => {
      const data = await chrome.storage.local.get(['disabledHosts', 'profiles', 'activeProfileId']);
      let hosts = (data.disabledHosts || []).filter(h => h !== btn.dataset.host);
      const profiles = data.profiles || {};
      const activeId = data.activeProfileId;
      if (activeId && profiles[activeId]) profiles[activeId].disabledHosts = hosts;
      await chrome.storage.local.set({ disabledHosts: hosts, profiles });
      renderBlacklist(hosts);
    });
  });
}